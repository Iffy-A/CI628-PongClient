#include "MyGame.h"

MyGame::MyGame(TTF_Font* font, SDL_Surface* bckgImg, SDL_Surface* bat1Img, SDL_Surface* bat2Img, SDL_Surface* ballImg) { this->font = font; this->bckgImg = bckgImg; this->bat1Img = bat1Img; this->bat2Img = bat2Img; this->ballImg = ballImg; }

void MyGame::on_receive(std::string cmd, std::vector<std::string>& args, std::string SCORES) {
    if (cmd == "GAME_DATA") {
        // we should have exactly 4 arguments
        if (args.size() == 4) {
            game_data.player1Y = stoi(args.at(0));
            game_data.player2Y = stoi(args.at(1));
            game_data.ballX = stoi(args.at(2));
            game_data.ballY = stoi(args.at(3));
        }
    } else {
        std::cout << "Received: " << cmd << std::endl;
    }

   if (cmd == "SCORES") {
        if (args.size() == 2) {
            plScores.player1score = stoi(args.at(0));
            plScores.player2score = stoi(args.at(1));
        }
    } else {
       //std::cout << "Received: " << cmd << std::endl;         //Prints too many messages to the terminal
    }
}

void MyGame::send(std::string message) {
    messages.push_back(message);
}

void MyGame::input(SDL_Event& event) {
    switch (event.key.keysym.sym) {
        case SDLK_w:
            send(event.type == SDL_KEYDOWN ? "W_DOWN" : "W_UP");
            break;
        case SDLK_s:
            send(event.type == SDL_KEYDOWN ? "S_DOWN" : "S_UP");
            break;
        case SDLK_i:
            send(event.type == SDL_KEYDOWN ? "I_DOWN" : "I_UP");
            break;
        case SDLK_k:
            send(event.type == SDL_KEYDOWN ? "K_DOWN" : "K_UP");
            break;
    }
}

void MyGame::update() {
    player1.y = game_data.player1Y;
    player2.y = game_data.player2Y;
    ball.x = game_data.ballX;
    ball.y = game_data.ballY;

   pl1score = plScores.player1score;
   pl2score = plScores.player2score;
}

void MyGame::render(SDL_Renderer* renderer) {
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 1);

    int tWidth = 800;
    int tHeight = 600;
    SDL_Texture* bTexture = SDL_CreateTextureFromSurface(renderer, bckgImg);
    SDL_Rect dst = { 0, 0, tWidth, tHeight };
    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, bTexture, NULL, NULL);

    SDL_Texture* bat1Texture = SDL_CreateTextureFromSurface(renderer, bat1Img);
    SDL_Texture* bat2Texture = SDL_CreateTextureFromSurface(renderer, bat2Img);
    SDL_Texture* ballTexture = SDL_CreateTextureFromSurface(renderer, ballImg);

    SDL_RenderDrawRect(renderer, &player1);
    SDL_RenderCopy(renderer, bat1Texture, NULL, &player1);

    SDL_RenderDrawRect(renderer, &player2);
    SDL_RenderCopy(renderer, bat2Texture, NULL, &player2);

    //SDL_RenderDrawRect(renderer, &ball);          // This gets rid of the border around the game object
    SDL_RenderCopy(renderer, ballTexture, NULL, &ball);

    std::string pl1String = std::to_string(pl1score);       //This is messy but doesn't give back a negative int and updates
    char const* pl1Str = pl1String.c_str();

    std::string pl2String = std::to_string(pl2score);
    char const* pl2Str = pl2String.c_str();
 
    SDL_Color tColour = { 255, 255, 255, 255 };
    SDL_Surface* pl1textSurface = TTF_RenderText_Blended(font, pl1Str, tColour);
    SDL_Surface* pl2textSurface = TTF_RenderText_Blended(font, pl2Str, tColour);

    if (pl1textSurface != nullptr) {        //Can clean up with a function
        SDL_Texture* pl1tTexture = SDL_CreateTextureFromSurface(renderer, pl1textSurface);
        SDL_FreeSurface(pl1textSurface);

        if (pl1tTexture != nullptr) {
            int w, h; //800 x 600
            SDL_QueryTexture(pl1tTexture, NULL, NULL, &w, &h);
            SDL_Rect dest = { 50, 100, w, h };
            SDL_RenderCopy(renderer, pl1tTexture, NULL, &dest); //null for whole texture
            SDL_DestroyTexture(pl1tTexture);
        }
    }

    if (pl2textSurface != nullptr) {
        SDL_Texture* pl2tTexture = SDL_CreateTextureFromSurface(renderer, pl2textSurface);
        SDL_FreeSurface(pl2textSurface);

        if (pl2tTexture != nullptr) {
            int w, h; //800 x 600
            SDL_QueryTexture(pl2tTexture, NULL, NULL, &w, &h);
            SDL_Rect dest = { 750, 100, w, h };
            SDL_RenderCopy(renderer, pl2tTexture, NULL, &dest); //null for whole texture
            SDL_DestroyTexture(pl2tTexture);
        }
    }
}
    /*void textDraw(SDL_Texture texture, int posX, int posY) {  //Unable to be called
        if (texture != nullptr) {
            int w, h; //800 x 600
            SDL_QueryTexture(texture, NULL, NULL, &w, &h);
            SDL_Rect dest = { posX, posY, w, h };
            SDL_RenderCopy(renderer, texture, NULL, &dest); //null for whole texture
            SDL_DestroyTexture(texture);
        }
    }*/