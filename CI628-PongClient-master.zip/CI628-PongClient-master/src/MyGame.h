#ifndef __MY_GAME_H__
#define __MY_GAME_H__

#include <iostream>
#include <vector>
#include <string>

#include "SDL_ttf.h"
#include "SDL_image.h"
#include "SDL.h"

static struct GameData {
    int player1Y = 0;
    int player2Y = 0;
    int ballX = 0;
    int ballY = 0;
} game_data;

static struct playerScores {
    int player1score = 0;
    int player2score = 0;
} plScores;

class MyGame {

    private:
        SDL_Rect player1 = { 200, 270, 20, 60 };
        SDL_Rect player2 = { 580, 270, 20, 60 };
        SDL_Rect ball = { 395, 270, 20, 20};        

        int pl1score, pl2score;
        
       TTF_Font* font;
       SDL_Surface* bckgImg;
       SDL_Surface* bat1Img;
       SDL_Surface* bat2Img;
       SDL_Surface* ballImg;
                        
    public:
        MyGame(TTF_Font* font, SDL_Surface* bckgImg, SDL_Surface* bat1Img, SDL_Surface* bat2Img, SDL_Surface* ballImg);
        std::vector<std::string> messages;

        void on_receive(std::string message, std::vector<std::string>& args, std::string SCORES);
        void send(std::string message);
        void input(SDL_Event& event);
        void update();
        void render(SDL_Renderer* renderer);
        //void textDraw(SDL_Renderer* renderer, SDL_Texture* texture, int posX, int posY);
};

#endif